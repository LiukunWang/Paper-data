import torch

ORIGIN_DIR = './input/origin/'
ANNOTATION_DIR = './output/annotation/'

TRAIN_SAMPLE_PATH = './output/train_sample.txt'
TEST_SAMPLE_PATH = './output/test_sample.txt'

VOCAB_PATH = 'output/vocab.txt'
LABEL_PATH = 'output/label.txt'

WORD_PAD = '<PAD>'
WORD_UNK = '<UNK>'
# WORD_PAD = '[PAD]'
# WORD_CLS = '[CLS]'
# WORD_SEP = '[SEP'
# WORD_MASK = '[MASK]'

WORD_PAD_ID = 0
WORD_UNK_ID = 1
# WORD_PAD_ID = 0
# WORD_SEP_ID = 1
# WORD_CLS_ID = 2
# WORD_MASK_ID = 3
LABEL_O_ID = 0

VOCAB_SIZE = 3000
EMBEDDING_DIM = 100
HIDDEN_SIZE = 256
TARGET_SIZE = 31
LR = 1e-4
EPOCH = 100

MODEL_DIR = './output/model/'

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
