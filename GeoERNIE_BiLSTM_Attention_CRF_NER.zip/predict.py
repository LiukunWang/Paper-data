from config import *
from utils import *
from model import *


def label_text(text):
    _, word2id = get_vocab()
    input = torch.tensor([[word2id.get(w, WORD_UNK_ID) for w in text]])
    mask = torch.tensor([[1] * len(text)]).bool()

    model = torch.load(MODEL_DIR + 'model_299.pth', map_location=DEVICE)
    y_pred = model(input, mask)
    id2label, _ = get_label()

    label = [id2label[l] for l in y_pred[0]]
    print(text.replace("\n", ""))
    print(label)
    info = extract(label, text)
    if len(info) > 0:
        print(info)
    else:
        print('==>此句无地质实体')
    print('\n')


def label_all_text():
    with open("./test.txt", encoding="utf-8") as f:
        label_text(f.read())


def label_text_line():
    with open("./test.txt", encoding="utf-8") as f:
        all_text = f.read().replace("\n", "")
        all_text = all_text.replace("。", "\n")
        all_text = all_text.replace("；", '\n')
        all_text = all_text.replace(";", '\n')
        all_text = all_text.replace(".", '\n')
        all_text = all_text.replace("，", '\n')
        f.close()

    path2 = "./new_test.txt"
    with open(path2, 'w', encoding="utf-8",) as f:
        f.write(all_text)

    with open(path2, encoding="utf-8") as f:
        for line in f.readlines():
            label_text(line)


if __name__ == '__main__':
    # print("------------------------------------------")
    # label_all_text()

    # print("--------------------提取结果----------------------\n\n")
    # label_text_line()

    print("------------------------------------------")
    label_text("研究区白垩系上统南雄群上亚群主要为（含炭质）岩屑石英砂岩，其次为钙质砂岩、（泥质）粉砂岩、细砂岩、砾岩及杂砂岩")
